"""Command line: offline verification and the conformance suite.

    shared-protocol verify-receipt receipt.json --key meg-anchor-2026-01.pub
    shared-protocol verify-checkpoint checkpoint.json --key meg-ckpt-2026-01.pub
    shared-protocol conformance

The first two are the purchaser's path of AC-R1: the document, its envelope
and a published key, nothing else.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from shared_protocol import __version__
from shared_protocol.errors import ProtocolError
from shared_protocol.receipts import (
    SignedDocument,
    load_keyring,
    verify_checkpoint,
    verify_receipt,
)


def main(argv: list[str] | None = None) -> int:
    """Run one command and return its exit status."""
    parser = argparse.ArgumentParser(prog="shared-protocol")
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("verify-receipt", "verify-checkpoint"):
        command = commands.add_parser(name)
        command.add_argument("signed", type=Path, help="the {document, envelope} file")
        command.add_argument("--key", type=Path, action="append", required=True)
    commands.add_parser("conformance", help="run the golden vectors against this install")
    args = parser.parse_args(argv)

    if args.command == "conformance":
        from shared_protocol.conformance import run

        failures = run()
        for failure in failures:
            print(f"FAIL {failure}")
        print("conformance: " + ("failed" if failures else "every golden vector holds"))
        return 1 if failures else 0

    try:
        signed = SignedDocument.from_json(args.signed.read_bytes())
        keyring = load_keyring(*(path.read_bytes() for path in args.key))
        if args.command == "verify-receipt":
            receipt = verify_receipt(signed, keyring)
            print(
                f"verified: site {receipt.receipt.site.name} seq {receipt.receipt.seq} "
                f"anchored {receipt.receipt.anchored_at.isoformat()} "
                f"by {receipt.verified.key_id} under {receipt.verified.alg}"
            )
        else:
            checkpoint = verify_checkpoint(signed, keyring)
            print(
                f"verified: checkpoint {checkpoint.checkpoint.seq} over "
                f"{len(checkpoint.checkpoint.heads)} sites, root "
                f"{checkpoint.checkpoint.estate_root}, by {checkpoint.verified.key_id} "
                f"under {checkpoint.verified.alg}"
            )
    except (ProtocolError, OSError) as error:
        print(f"not verified: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
