"""Policy documents and their acknowledgement. SAD 13.1, threats M6 and M11.

A policy version is signed by MEGINGJORD's policy key (Decision M5) and
pulled by a site. The site verifies it against the expected policy key before
adopting it (AC-M11: `verify_policy` is that check) and acknowledges adoption
with a document signed by its own key, so that "distributed and acknowledged"
(SAD 29) is something each site said, not something MEGINGJORD assumed.

Bodies are closed: every kind has a fixed schema and an unknown key is
refused (SAD 11: "its schema is closed"). They follow GLEIPNIR, the DRAUPNIR
policy engine that judges against them (G3 decision):

- `licence` and `copyright`: an ordered rule set, first match wins, and an
  unmatched subject gets the default verdict. Each rule names SPDX licences
  and optional personal-data and attribution conditions.
- `gates`: gate definitions, as GLEIPNIR's `Gate`. A margin travels as a
  decimal string: the protocol's canonical JSON carries integers only, so
  that a signed document has exactly one byte form.
- `retention`: whole years to keep the ledger, receipts and checkpoints.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any, Final
from uuid import UUID

from shared_protocol import fields
from shared_protocol.canonical import canonicalise
from shared_protocol.digest import Digest, parse_digest
from shared_protocol.documents import _Document
from shared_protocol.errors import DocumentError

POLICY_KIND: Final = "megingjord.policy"
ACKNOWLEDGEMENT_KIND: Final = "megingjord.policy-acknowledgement"

MAX_STATEMENT: Final = 512
MAX_RULES: Final = 256
_RULE_ID: Final = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}\Z")
_SPDX: Final = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.+-]{0,63}\Z")
_DECIMAL: Final = re.compile(r"^-?(0|[1-9][0-9]{0,5})(\.[0-9]{1,6})?\Z")


class PolicyKind(StrEnum):
    """The four policy kinds of SAD 18, E10."""

    LICENCE = "licence"
    COPYRIGHT = "copyright"
    RETENTION = "retention"
    GATES = "gates"


class Verdict(StrEnum):
    """GLEIPNIR's verdicts."""

    PERMIT = "PERMIT"
    REFUSE = "REFUSE"
    REQUIRES_APPROVAL = "REQUIRES_APPROVAL"


class Comparison(StrEnum):
    """GLEIPNIR's gate comparisons."""

    NO_WORSE_THAN = "no-worse-than"
    BETTER_THAN = "better-than"
    AT_MOST = "at-most"
    AT_LEAST = "at-least"


def _closed(
    value: object, path: str, keys: set[str], optional: frozenset[str] = frozenset()
) -> Mapping[str, Any]:
    mapping = fields.require_mapping(value, path)
    unknown = set(mapping) - keys - optional
    if unknown:
        raise DocumentError(path, f"unknown keys {sorted(unknown)}: the body schema is closed")
    missing = keys - set(mapping)
    if missing:
        raise DocumentError(path, f"missing keys {sorted(missing)}")
    return mapping


def _text(value: object, path: str) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > MAX_STATEMENT:
        raise DocumentError(path, f"expected a statement of 1 to {MAX_STATEMENT} characters")
    if any(ord(c) < 0x20 for c in value):
        raise DocumentError(path, "a statement carries no control characters")
    return value


def _enum(value: object, path: str, kind: type[StrEnum]) -> str:
    if not isinstance(value, str) or value not in {m.value for m in kind}:
        raise DocumentError(path, f"expected one of {[m.value for m in kind]}")
    return value


def _optional_bool(value: object, path: str) -> bool | None:
    if value is not None and not isinstance(value, bool):
        raise DocumentError(path, "expected true, false or null")
    return value


def _list(value: object, path: str, *, maximum: int, minimum: int = 0) -> list[Any]:
    if not isinstance(value, list) or not minimum <= len(value) <= maximum:
        raise DocumentError(path, f"expected an array of {minimum} to {maximum} items")
    return value


def _rule_set(body: object) -> dict[str, Any]:
    doc = _closed(body, "body", {"rules", "default", "default_statement"})
    rules = []
    seen: set[str] = set()
    for i, raw in enumerate(_list(doc["rules"], "body.rules", maximum=MAX_RULES, minimum=1)):
        path = f"body.rules[{i}]"
        rule = _closed(
            raw, path, {"id", "statement", "verdict"},
            optional=frozenset({"licences", "personal_data", "attribution_required"}),
        )  # fmt: skip
        rule_id = rule["id"]
        if not isinstance(rule_id, str) or not _RULE_ID.match(rule_id) or rule_id in seen:
            raise DocumentError(f"{path}.id", "expected a unique short identifier")
        seen.add(rule_id)
        licences = _list(rule.get("licences", []), f"{path}.licences", maximum=64)
        for j, spdx in enumerate(licences):
            if not isinstance(spdx, str) or not _SPDX.match(spdx):
                raise DocumentError(f"{path}.licences[{j}]", "expected an SPDX identifier")
        rules.append(
            {
                "id": rule_id,
                "statement": _text(rule["statement"], f"{path}.statement"),
                "verdict": _enum(rule["verdict"], f"{path}.verdict", Verdict),
                "licences": list(licences),
                "personal_data": _optional_bool(rule.get("personal_data"), f"{path}.personal_data"),
                "attribution_required": _optional_bool(
                    rule.get("attribution_required"), f"{path}.attribution_required"
                ),
            }
        )
    return {
        "rules": rules,
        "default": _enum(doc["default"], "body.default", Verdict),
        "default_statement": _text(doc["default_statement"], "body.default_statement"),
    }


def _gates(body: object) -> dict[str, Any]:
    doc = _closed(body, "body", {"gates"})
    gates = []
    seen: set[str] = set()
    for i, raw in enumerate(_list(doc["gates"], "body.gates", maximum=MAX_RULES, minimum=1)):
        path = f"body.gates[{i}]"
        gate = _closed(raw, path, {"id", "statement", "comparison", "margin", "blocking"})
        gate_id = gate["id"]
        if not isinstance(gate_id, str) or not _RULE_ID.match(gate_id) or gate_id in seen:
            raise DocumentError(f"{path}.id", "expected a unique short identifier")
        seen.add(gate_id)
        margin = gate["margin"]
        if not isinstance(margin, str) or not _DECIMAL.match(margin):
            raise DocumentError(f"{path}.margin", 'expected a decimal string such as "0.02"')
        if not isinstance(gate["blocking"], bool):
            raise DocumentError(f"{path}.blocking", "expected true or false")
        gates.append(
            {
                "id": gate_id,
                "statement": _text(gate["statement"], f"{path}.statement"),
                "comparison": _enum(gate["comparison"], f"{path}.comparison", Comparison),
                "margin": margin,
                "blocking": gate["blocking"],
            }
        )
    return {"gates": gates}


def _retention(body: object) -> dict[str, Any]:
    doc = _closed(body, "body", {"ledger_years", "receipt_years", "checkpoint_years"})
    out = {}
    for key in ("ledger_years", "receipt_years", "checkpoint_years"):
        years = fields.integer(doc[key], f"body.{key}", minimum=1)
        if years > 1000:
            raise DocumentError(f"body.{key}", "at most 1000 years")
        out[key] = years
    return out


_BODIES: Final = {
    PolicyKind.LICENCE: _rule_set,
    PolicyKind.COPYRIGHT: _rule_set,
    PolicyKind.GATES: _gates,
    PolicyKind.RETENTION: _retention,
}


def validate_body(kind: PolicyKind, body: object) -> dict[str, Any]:
    """The body in its normal form, or `DocumentError` naming what is wrong."""
    return _BODIES[kind](body)


@dataclass(frozen=True, slots=True)
class PolicyDocument(_Document):
    """One policy version, as signed and distributed."""

    policy_kind: PolicyKind
    version: int
    effective_from: datetime
    body: Mapping[str, Any]
    key_id: str
    algorithms: tuple[str, ...]
    v: int = fields.PROTOCOL_MAJOR
    kind: str = field(default=POLICY_KIND)

    def __post_init__(self) -> None:
        """Refuse a policy a site could not judge against."""
        if self.v not in fields.SUPPORTED_MAJORS:
            fields.require_major({"v": self.v})
        if self.kind != POLICY_KIND:
            raise DocumentError("kind", f"expected {POLICY_KIND!r}")
        object.__setattr__(self, "policy_kind", PolicyKind(self.policy_kind))
        fields.integer(self.version, "version", minimum=1)
        object.__setattr__(
            self, "effective_from", fields.check_instant(self.effective_from, "effective_from")
        )
        object.__setattr__(self, "body", validate_body(self.policy_kind, self.body))
        if len(canonicalise(dict(self.body))) > 65536:
            raise DocumentError("body", "a policy body is at most 64 KiB")
        fields.key_id(self.key_id, "key_id")
        if not self.algorithms or len(set(self.algorithms)) != len(self.algorithms):
            raise DocumentError("algorithms", "expected distinct algorithm names")
        for i, name in enumerate(self.algorithms):
            fields.algorithm_name(name, f"algorithms[{i}]")

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {
            "v": self.v,
            "kind": self.kind,
            "policy_kind": str(self.policy_kind),
            "version": self.version,
            "effective_from": fields.render_instant(self.effective_from),
            "body": dict(self.body),
            "key_id": self.key_id,
            "algorithms": list(self.algorithms),
        }

    @classmethod
    def from_wire(cls, value: object) -> PolicyDocument:
        """Parse a received policy."""
        doc = fields.require_mapping(value, "$")
        v = fields.require_major(doc)
        if fields.require(doc, "kind") != POLICY_KIND:
            raise DocumentError("kind", f"expected {POLICY_KIND!r}")
        algorithms = fields.require(doc, "algorithms")
        if not isinstance(algorithms, list):
            raise DocumentError("algorithms", "expected an array")
        return cls(
            v=v,
            policy_kind=PolicyKind(
                _enum(fields.require(doc, "policy_kind"), "policy_kind", PolicyKind)
            ),
            version=fields.integer(fields.require(doc, "version"), "version", minimum=1),
            effective_from=fields.timestamp(
                fields.require(doc, "effective_from"), "effective_from"
            ),
            body=fields.require(doc, "body"),
            key_id=fields.key_id(fields.require(doc, "key_id"), "key_id"),
            algorithms=tuple(algorithms),
        )


@dataclass(frozen=True, slots=True)
class PolicyAcknowledgement(_Document):
    """A site's statement that it verified and adopted a policy version.

    Signed by the site's key. `policy_hash` is the payload hash of the policy
    document it adopted, so an acknowledgement names exactly one signed
    document and cannot be replayed onto another version.
    """

    site_id: UUID
    policy_kind: PolicyKind
    version: int
    policy_hash: Digest
    acknowledged_at: datetime
    v: int = fields.PROTOCOL_MAJOR
    kind: str = field(default=ACKNOWLEDGEMENT_KIND)

    def __post_init__(self) -> None:
        """Refuse an acknowledgement that names nothing exactly."""
        if self.v not in fields.SUPPORTED_MAJORS:
            fields.require_major({"v": self.v})
        if self.kind != ACKNOWLEDGEMENT_KIND:
            raise DocumentError("kind", f"expected {ACKNOWLEDGEMENT_KIND!r}")
        object.__setattr__(self, "policy_kind", PolicyKind(self.policy_kind))
        fields.integer(self.version, "version", minimum=1)
        parse_digest(self.policy_hash, field="policy_hash")
        object.__setattr__(
            self, "acknowledged_at", fields.check_instant(self.acknowledged_at, "acknowledged_at")
        )

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {
            "v": self.v,
            "kind": self.kind,
            "site_id": str(self.site_id),
            "policy_kind": str(self.policy_kind),
            "version": self.version,
            "policy_hash": self.policy_hash,
            "acknowledged_at": fields.render_instant(self.acknowledged_at),
        }

    @classmethod
    def from_wire(cls, value: object) -> PolicyAcknowledgement:
        """Parse a received acknowledgement."""
        doc = fields.require_mapping(value, "$")
        v = fields.require_major(doc)
        if fields.require(doc, "kind") != ACKNOWLEDGEMENT_KIND:
            raise DocumentError("kind", f"expected {ACKNOWLEDGEMENT_KIND!r}")
        return cls(
            v=v,
            site_id=fields.uuid(fields.require(doc, "site_id"), "site_id"),
            policy_kind=PolicyKind(
                _enum(fields.require(doc, "policy_kind"), "policy_kind", PolicyKind)
            ),
            version=fields.integer(fields.require(doc, "version"), "version", minimum=1),
            policy_hash=parse_digest(fields.require(doc, "policy_hash"), field="policy_hash"),
            acknowledged_at=fields.timestamp(
                fields.require(doc, "acknowledged_at"), "acknowledged_at"
            ),
        )
