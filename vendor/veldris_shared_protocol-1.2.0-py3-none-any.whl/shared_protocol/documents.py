"""The wire documents: anchor head, anchor receipt, checkpoint. SAD section 12.

Each type validates on construction and on `from_wire`, so an instance that
exists is a document the protocol can carry. `from_wire` ignores fields it
does not know (SAD 33.2: a minor version adds optional fields, and an end must
ignore rather than fail on them). A signature is always verified over the
document as received, before it is parsed into one of these types, so an
ignored field is still covered by the signature it arrived under.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Final
from uuid import UUID

from shared_protocol import fields
from shared_protocol.canonical import canonicalise
from shared_protocol.digest import Digest, parse_digest, sha256_digest
from shared_protocol.errors import DocumentError
from shared_protocol.merkle import merkle_root

RECEIPT_KIND: Final = "megingjord.anchor-receipt"
CHECKPOINT_KIND: Final = "megingjord.checkpoint"

#: A checkpoint names every site's head. An estate is a handful of forges; a
#: bound keeps a checkpoint from being a vehicle for anything else.
MAX_CHECKPOINT_HEADS: Final = 10_000


def _algorithms(value: object, path: str) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)) or not value:
        raise DocumentError(path, "expected a non-empty array of algorithm names")
    names = tuple(fields.algorithm_name(item, f"{path}[{i}]") for i, item in enumerate(value))
    if len(set(names)) != len(names):
        raise DocumentError(path, "an algorithm appears twice")
    if len(names) > 8:
        raise DocumentError(path, "at most eight algorithms")
    return names


class _Document:
    """Behaviour shared by every signable document."""

    def to_wire(self) -> dict[str, Any]:
        raise NotImplementedError

    def canonical(self) -> bytes:
        """The RFC 8785 bytes a signature over this document covers."""
        return canonicalise(self.to_wire())

    def payload_hash(self) -> Digest:
        """The digest an envelope over this document names."""
        return sha256_digest(self.canonical())


@dataclass(frozen=True, slots=True)
class AnchorHead(_Document):
    """SAD 12.1. The head of a site's local ledger, submitted for anchoring."""

    site_id: UUID
    seq: int
    entry_hash: Digest
    prev_anchor_hash: Digest | None
    issued_at: datetime
    agent: str
    v: int = fields.PROTOCOL_MAJOR

    def __post_init__(self) -> None:
        """Refuse a head the protocol cannot carry."""
        if self.v not in fields.SUPPORTED_MAJORS:
            fields.require_major({"v": self.v})
        fields.integer(self.seq, "seq")
        parse_digest(self.entry_hash, field="entry_hash")
        if self.prev_anchor_hash is not None:
            parse_digest(self.prev_anchor_hash, field="prev_anchor_hash")
        object.__setattr__(self, "issued_at", fields.check_instant(self.issued_at, "issued_at"))
        fields.agent(self.agent, "agent")

    def to_wire(self) -> dict[str, Any]:
        """The wire shape, field names exactly as SAD 12.1."""
        return {
            "v": self.v,
            "site_id": str(self.site_id),
            "seq": self.seq,
            "entry_hash": self.entry_hash,
            "prev_anchor_hash": self.prev_anchor_hash,
            "issued_at": fields.render_instant(self.issued_at),
            "agent": self.agent,
        }

    @classmethod
    def from_wire(cls, value: object) -> AnchorHead:
        """Parse a received head. The major is checked before anything else."""
        doc = fields.require_mapping(value, "$")
        v = fields.require_major(doc)
        prev = fields.require(doc, "prev_anchor_hash")
        return cls(
            v=v,
            site_id=fields.uuid(fields.require(doc, "site_id"), "site_id"),
            seq=fields.integer(fields.require(doc, "seq"), "seq"),
            entry_hash=parse_digest(fields.require(doc, "entry_hash"), field="entry_hash"),
            prev_anchor_hash=None if prev is None else parse_digest(prev, field="prev_anchor_hash"),
            issued_at=fields.timestamp(fields.require(doc, "issued_at"), "issued_at"),
            agent=fields.agent(fields.require(doc, "agent"), "agent"),
        )


@dataclass(frozen=True, slots=True)
class ReceiptSite:
    """The site a receipt names: identifier, name and ordinal."""

    id: UUID
    name: str
    ordinal: int

    def __post_init__(self) -> None:
        """Refuse a site the receipt cannot name."""
        fields.name(self.name, "site.name")
        fields.integer(self.ordinal, "site.ordinal")

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {"id": str(self.id), "name": self.name, "ordinal": self.ordinal}

    @classmethod
    def from_wire(cls, value: object) -> ReceiptSite:
        """Parse the `site` member of a receipt."""
        doc = fields.require_mapping(value, "site")
        return cls(
            id=fields.uuid(fields.require(doc, "id"), "site.id"),
            name=fields.name(fields.require(doc, "name"), "site.name"),
            ordinal=fields.integer(fields.require(doc, "ordinal"), "site.ordinal"),
        )


@dataclass(frozen=True, slots=True)
class AnchorReceipt(_Document):
    """SAD 12.5. What a purchaser verifies offline, with the published key alone."""

    site: ReceiptSite
    seq: int
    entry_hash: Digest
    anchored_at: datetime
    checkpoint_seq: int
    key_id: str
    algorithms: tuple[str, ...]
    v: int = fields.PROTOCOL_MAJOR
    kind: str = field(default=RECEIPT_KIND)

    def __post_init__(self) -> None:
        """Refuse a receipt that could not be verified."""
        if self.v not in fields.SUPPORTED_MAJORS:
            fields.require_major({"v": self.v})
        if self.kind != RECEIPT_KIND:
            raise DocumentError("kind", f"expected {RECEIPT_KIND!r}")
        fields.integer(self.seq, "seq")
        parse_digest(self.entry_hash, field="entry_hash")
        object.__setattr__(
            self, "anchored_at", fields.check_instant(self.anchored_at, "anchored_at")
        )
        fields.integer(self.checkpoint_seq, "checkpoint_seq")
        fields.key_id(self.key_id, "key_id")
        object.__setattr__(self, "algorithms", _algorithms(self.algorithms, "algorithms"))

    def to_wire(self) -> dict[str, Any]:
        """The wire shape, field names exactly as SAD 12.5."""
        return {
            "v": self.v,
            "kind": self.kind,
            "site": self.site.to_wire(),
            "seq": self.seq,
            "entry_hash": self.entry_hash,
            "anchored_at": fields.render_instant(self.anchored_at),
            "checkpoint_seq": self.checkpoint_seq,
            "key_id": self.key_id,
            "algorithms": list(self.algorithms),
        }

    @classmethod
    def from_wire(cls, value: object) -> AnchorReceipt:
        """Parse a received receipt."""
        doc = fields.require_mapping(value, "$")
        v = fields.require_major(doc)
        if fields.require(doc, "kind") != RECEIPT_KIND:
            raise DocumentError("kind", f"expected {RECEIPT_KIND!r}")
        return cls(
            v=v,
            site=ReceiptSite.from_wire(fields.require(doc, "site")),
            seq=fields.integer(fields.require(doc, "seq"), "seq"),
            entry_hash=parse_digest(fields.require(doc, "entry_hash"), field="entry_hash"),
            anchored_at=fields.timestamp(fields.require(doc, "anchored_at"), "anchored_at"),
            checkpoint_seq=fields.integer(fields.require(doc, "checkpoint_seq"), "checkpoint_seq"),
            key_id=fields.key_id(fields.require(doc, "key_id"), "key_id"),
            algorithms=_algorithms(fields.require(doc, "algorithms"), "algorithms"),
        )


@dataclass(frozen=True, slots=True)
class CheckpointHead:
    """One site's head as a checkpoint records it."""

    site_id: UUID
    seq: int
    entry_hash: Digest

    def __post_init__(self) -> None:
        """Refuse a head the checkpoint cannot carry."""
        fields.integer(self.seq, "heads[].seq")
        parse_digest(self.entry_hash, field="heads[].entry_hash")

    def to_wire(self) -> dict[str, Any]:
        """The wire shape, and the Merkle leaf: canonical bytes of this object."""
        return {"site_id": str(self.site_id), "seq": self.seq, "entry_hash": self.entry_hash}

    @classmethod
    def from_wire(cls, value: object, path: str) -> CheckpointHead:
        """Parse one entry of `heads`."""
        doc = fields.require_mapping(value, path)
        return cls(
            site_id=fields.uuid(fields.require(doc, "site_id"), f"{path}.site_id"),
            seq=fields.integer(fields.require(doc, "seq"), f"{path}.seq"),
            entry_hash=parse_digest(fields.require(doc, "entry_hash"), field=f"{path}.entry_hash"),
        )


def estate_root(heads: Sequence[CheckpointHead]) -> Digest:
    """The RFC 6962 root over the canonical bytes of each head, in site order."""
    return merkle_root([canonicalise(head.to_wire()) for head in heads])


@dataclass(frozen=True, slots=True)
class Checkpoint(_Document):
    """SAD 12.6. Every site's head at an instant, and an estate root over them.

    The shape is a G0 decision filling a gap in SAD 12.6, recorded in SPEC.md.
    Heads are ordered by `site_id` so that one estate state has one document,
    and the root is checked on construction, so a checkpoint whose root does
    not follow from its heads cannot be built, signed or parsed.
    """

    seq: int
    issued_at: datetime
    heads: tuple[CheckpointHead, ...]
    estate_root: Digest
    key_id: str
    algorithms: tuple[str, ...]
    v: int = fields.PROTOCOL_MAJOR
    kind: str = field(default=CHECKPOINT_KIND)

    def __post_init__(self) -> None:
        """Refuse a checkpoint whose heads and root disagree."""
        if self.v not in fields.SUPPORTED_MAJORS:
            fields.require_major({"v": self.v})
        if self.kind != CHECKPOINT_KIND:
            raise DocumentError("kind", f"expected {CHECKPOINT_KIND!r}")
        fields.integer(self.seq, "seq")
        object.__setattr__(self, "issued_at", fields.check_instant(self.issued_at, "issued_at"))
        if len(self.heads) > MAX_CHECKPOINT_HEADS:
            raise DocumentError("heads", f"at most {MAX_CHECKPOINT_HEADS} sites")
        ids = [str(head.site_id) for head in self.heads]
        if ids != sorted(ids) or len(set(ids)) != len(ids):
            raise DocumentError("heads", "heads are ordered by site_id, one per site")
        parse_digest(self.estate_root, field="estate_root")
        if self.estate_root != estate_root(self.heads):
            raise DocumentError("estate_root", "does not follow from the heads")
        fields.key_id(self.key_id, "key_id")
        object.__setattr__(self, "algorithms", _algorithms(self.algorithms, "algorithms"))

    @classmethod
    def build(
        cls,
        *,
        seq: int,
        issued_at: datetime,
        heads: Sequence[CheckpointHead],
        key_id: str,
        algorithms: Sequence[str],
    ) -> Checkpoint:
        """Order the heads and compute the root. The way a checkpoint is made."""
        ordered = tuple(sorted(heads, key=lambda head: str(head.site_id)))
        return cls(
            seq=seq,
            issued_at=issued_at,
            heads=ordered,
            estate_root=estate_root(ordered),
            key_id=key_id,
            algorithms=tuple(algorithms),
        )

    def head_for(self, site_id: UUID) -> CheckpointHead | None:
        """The head this checkpoint records for a site, if any."""
        return next((head for head in self.heads if head.site_id == site_id), None)

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {
            "v": self.v,
            "kind": self.kind,
            "seq": self.seq,
            "issued_at": fields.render_instant(self.issued_at),
            "heads": [head.to_wire() for head in self.heads],
            "estate_root": self.estate_root,
            "key_id": self.key_id,
            "algorithms": list(self.algorithms),
        }

    @classmethod
    def from_wire(cls, value: object) -> Checkpoint:
        """Parse a received checkpoint."""
        doc = fields.require_mapping(value, "$")
        v = fields.require_major(doc)
        if fields.require(doc, "kind") != CHECKPOINT_KIND:
            raise DocumentError("kind", f"expected {CHECKPOINT_KIND!r}")
        raw_heads = fields.require(doc, "heads")
        if not isinstance(raw_heads, list):
            raise DocumentError("heads", "expected an array")
        if len(raw_heads) > MAX_CHECKPOINT_HEADS:
            raise DocumentError("heads", f"at most {MAX_CHECKPOINT_HEADS} sites")
        return cls(
            v=v,
            seq=fields.integer(fields.require(doc, "seq"), "seq"),
            issued_at=fields.timestamp(fields.require(doc, "issued_at"), "issued_at"),
            heads=tuple(
                CheckpointHead.from_wire(item, f"heads[{i}]") for i, item in enumerate(raw_heads)
            ),
            estate_root=parse_digest(fields.require(doc, "estate_root"), field="estate_root"),
            key_id=fields.key_id(fields.require(doc, "key_id"), "key_id"),
            algorithms=_algorithms(fields.require(doc, "algorithms"), "algorithms"),
        )
