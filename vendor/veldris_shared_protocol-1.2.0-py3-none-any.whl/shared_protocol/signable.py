"""Every document kind the protocol signs. Nothing else can be sealed (threat M7)."""

from __future__ import annotations

from shared_protocol.attestation import Attestation
from shared_protocol.documents import AnchorHead, AnchorReceipt, Checkpoint
from shared_protocol.policy import PolicyAcknowledgement, PolicyDocument
from shared_protocol.release import ModelRelease

#: Signed by MEGINGJORD, naming their own key and algorithms.
AuthorityDocument = AnchorReceipt | Checkpoint | PolicyDocument | Attestation

#: Signed by a site with its own key.
SiteDocument = AnchorHead | PolicyAcknowledgement | ModelRelease

SignableDocument = AuthorityDocument | SiteDocument


def document_kind(document: SignableDocument) -> str:
    """A name for the document's kind, for messages and the key provider."""
    if isinstance(document, AnchorHead):
        return "megingjord.anchor-head"
    return document.kind
