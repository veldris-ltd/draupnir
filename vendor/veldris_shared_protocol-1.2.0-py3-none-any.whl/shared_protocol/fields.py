"""Field validators shared by every wire type.

Every field the protocol carries is a hash, an identifier, a timestamp, an
integer or a short constrained name. There is no free-text field and no
unbounded string, which is what makes AC-P13 a property of the types rather
than of a review: a payload cannot be smuggled through a field whose every
legal value is matched by a short regular expression.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any, Final
from uuid import UUID

from shared_protocol.canonical import MAX_SAFE_INTEGER
from shared_protocol.errors import DocumentError, ProtocolVersionError

#: Protocol majors this package speaks. SAD 33.2: the server supports the
#: current and the immediately previous major; there is no previous yet.
PROTOCOL_MAJOR: Final = 1
SUPPORTED_MAJORS: Final[tuple[int, ...]] = (1,)

_UUID: Final = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\Z")
_TIMESTAMP: Final = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z\Z")
_NAME: Final = re.compile(r"^[a-z][a-z0-9-]{0,63}\Z")
_KEY_ID: Final = re.compile(r"^[a-z][a-z0-9-]{2,63}\Z")
_AGENT_PRODUCT: Final = (
    r"[a-z][a-z0-9-]{0,63}/(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})"
)
_AGENT: Final = re.compile(rf"^{_AGENT_PRODUCT}(?: {_AGENT_PRODUCT}){{0,3}}\Z")
_ALGORITHM: Final = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}\Z")

MAX_AGENT_LENGTH: Final = 160


def require_mapping(value: object, field: str) -> Mapping[str, Any]:
    """The value is a JSON object."""
    if not isinstance(value, Mapping):
        raise DocumentError(field, f"expected an object, got {type(value).__name__}")
    return value


def require_major(document: Mapping[str, Any], field: str = "v") -> int:
    """Rule 4: the declared major is one this package speaks. Checked first."""
    if field not in document:
        raise DocumentError(field, "the protocol major is missing")
    value = document[field]
    if isinstance(value, bool) or not isinstance(value, int):
        raise DocumentError(field, "the protocol major is not an integer")
    if value not in SUPPORTED_MAJORS:
        raise ProtocolVersionError(value, SUPPORTED_MAJORS)
    return value


def require(document: Mapping[str, Any], field: str) -> Any:
    """The field is present. Absence and null are different things."""
    if field not in document:
        raise DocumentError(field, "required and missing")
    return document[field]


def integer(value: object, field: str, *, minimum: int = 0) -> int:
    """A non-boolean integer, at least `minimum`, inside the I-JSON safe range."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise DocumentError(field, f"expected an integer, got {type(value).__name__}")
    if not minimum <= value <= MAX_SAFE_INTEGER:
        raise DocumentError(field, f"must be between {minimum} and {MAX_SAFE_INTEGER}")
    return value


def uuid(value: object, field: str) -> UUID:
    """A UUID in lowercase hyphenated form, the only form the wire carries."""
    if not isinstance(value, str) or not _UUID.match(value):
        raise DocumentError(field, "expected a lowercase hyphenated UUID")
    return UUID(value)


def timestamp(value: object, field: str) -> datetime:
    """`YYYY-MM-DDTHH:MM:SSZ`. UTC, whole seconds, one spelling.

    RFC 3339 admits many spellings of one instant. A signed document admits
    one, so that the bytes a site signed are the bytes a verifier rebuilds.
    """
    if not isinstance(value, str) or not _TIMESTAMP.match(value):
        raise DocumentError(field, "expected an RFC 3339 UTC timestamp, YYYY-MM-DDTHH:MM:SSZ")
    try:
        parsed = datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")
    except ValueError as error:
        raise DocumentError(field, "not a real date and time") from error
    return parsed.replace(tzinfo=UTC)


def check_instant(value: datetime, field: str) -> datetime:
    """A datetime that can be written in the one spelling: aware, whole seconds."""
    if value.tzinfo is None or value.utcoffset() is None:
        raise DocumentError(field, "a naive datetime has no instant; give it an offset")
    if value.microsecond:
        raise DocumentError(field, "the wire carries whole seconds")
    return value.astimezone(UTC)


def render_instant(value: datetime) -> str:
    """The one spelling of an instant."""
    return value.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def name(value: object, field: str) -> str:
    """A site name: lowercase, starts with a letter, at most 64 characters."""
    if not isinstance(value, str) or not _NAME.match(value):
        raise DocumentError(field, "expected a lowercase name of at most 64 characters")
    return value


def key_id(value: object, field: str) -> str:
    """A key identifier, e.g. `meg-anchor-2026-01`."""
    if not isinstance(value, str) or not _KEY_ID.match(value):
        raise DocumentError(field, "expected a lowercase key identifier of 3 to 64 characters")
    return value


def agent(value: object, field: str) -> str:
    """One to four `name/major.minor.patch` tokens, space separated.

    SAD 12.1 gives `gullinbursti/1.2.0`; SAD 33.2 says the shared-protocol
    version is recorded in the same field. Both readings are satisfied by
    `gullinbursti/1.2.0 shared-protocol/1.0.0`.
    """
    if not isinstance(value, str) or len(value) > MAX_AGENT_LENGTH or not _AGENT.match(value):
        raise DocumentError(field, "expected product tokens of the form name/1.2.3")
    return value


def algorithm_name(value: object, field: str) -> str:
    """The shape of an algorithm name, known or not."""
    if not isinstance(value, str) or not _ALGORITHM.match(value):
        raise DocumentError(field, "expected a lowercase algorithm name")
    return value
