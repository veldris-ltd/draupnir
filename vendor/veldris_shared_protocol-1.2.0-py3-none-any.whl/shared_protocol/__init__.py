"""The MEGINGJORD anchoring protocol, shared by MEGINGJORD and GULLINBURSTI.

VLD-SAD-MEGINGJORD-001 Decision M4: the wire format is the contract between
two systems in different repositories on different release schedules, so it is
one versioned package with its own conformance suite, consumed by both ends.

This package imports nothing from MEGINGJORD or DRAUPNIR (AC-B7). Its only
runtime dependency is `cryptography`.
"""

from shared_protocol.attestation import ATTESTATION_KIND, Attestation
from shared_protocol.canonical import CanonicalisationError, canonicalise, loads
from shared_protocol.digest import Digest, HashAlgorithm, parse_digest, sha256_digest
from shared_protocol.documents import (
    CHECKPOINT_KIND,
    RECEIPT_KIND,
    AnchorHead,
    AnchorReceipt,
    Checkpoint,
    CheckpointHead,
    ReceiptSite,
    estate_root,
)
from shared_protocol.envelope import (
    Ed25519Signer,
    Envelope,
    MLDSA65Signer,
    Signature,
    Signer,
    Verified,
    seal,
    verify,
)
from shared_protocol.errors import (
    DocumentError,
    ProtocolError,
    ProtocolVersionError,
    SignatureInvalidError,
)
from shared_protocol.fields import PROTOCOL_MAJOR, SUPPORTED_MAJORS
from shared_protocol.keys import Algorithm, KeyPurpose, Keyring, PublicKey, PublishedKey
from shared_protocol.policy import (
    ACKNOWLEDGEMENT_KIND,
    POLICY_KIND,
    PolicyAcknowledgement,
    PolicyDocument,
    PolicyKind,
    validate_body,
)
from shared_protocol.problems import PROBLEM_BASE, Problem, ProblemSpec
from shared_protocol.receipts import (
    SignedDocument,
    VerifiedAttestation,
    VerifiedCheckpoint,
    VerifiedPolicy,
    VerifiedReceipt,
    load_keyring,
    verify_attestation,
    verify_checkpoint,
    verify_policy,
    verify_receipt,
)
from shared_protocol.release import RELEASE_KIND, ModelRelease
from shared_protocol.signable import AuthorityDocument, SignableDocument, SiteDocument

__version__ = "1.2.0"

#: The agent token this package contributes, per SAD 33.2.
AGENT_TOKEN = f"shared-protocol/{__version__}"

__all__ = [
    "ATTESTATION_KIND",
    "Attestation",
    "VerifiedAttestation",
    "verify_attestation",
    "ACKNOWLEDGEMENT_KIND",
    "AGENT_TOKEN",
    "CHECKPOINT_KIND",
    "POLICY_KIND",
    "PROBLEM_BASE",
    "PROTOCOL_MAJOR",
    "RECEIPT_KIND",
    "RELEASE_KIND",
    "SUPPORTED_MAJORS",
    "Algorithm",
    "AnchorHead",
    "AnchorReceipt",
    "AuthorityDocument",
    "CanonicalisationError",
    "Checkpoint",
    "CheckpointHead",
    "Digest",
    "DocumentError",
    "Ed25519Signer",
    "Envelope",
    "HashAlgorithm",
    "KeyPurpose",
    "Keyring",
    "MLDSA65Signer",
    "ModelRelease",
    "PolicyAcknowledgement",
    "PolicyDocument",
    "PolicyKind",
    "Problem",
    "ProblemSpec",
    "ProtocolError",
    "ProtocolVersionError",
    "PublicKey",
    "PublishedKey",
    "ReceiptSite",
    "SignableDocument",
    "Signature",
    "SignatureInvalidError",
    "SignedDocument",
    "Signer",
    "SiteDocument",
    "Verified",
    "VerifiedCheckpoint",
    "VerifiedPolicy",
    "VerifiedReceipt",
    "canonicalise",
    "estate_root",
    "load_keyring",
    "loads",
    "parse_digest",
    "seal",
    "sha256_digest",
    "validate_body",
    "verify",
    "verify_checkpoint",
    "verify_policy",
    "verify_receipt",
    "__version__",
]
