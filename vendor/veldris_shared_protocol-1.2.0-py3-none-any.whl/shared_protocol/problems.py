"""RFC 9457 problem types for anchor intake. SAD 12.2 and AC-P12.

Every rejection has its own stable type URI so that an agent can tell a
sequence gap from a chain discontinuity without parsing prose. They live in
the shared package because both ends depend on them: MEGINGJORD emits them and
GULLINBURSTI branches on them, and a URI spelt twice is a URI spelt two ways.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Final

PROBLEM_BASE: Final = "https://veldris.internal/problems/megingjord/"


@dataclass(frozen=True, slots=True)
class ProblemSpec:
    """One problem type: its slug, HTTP status, title and the rule it enforces."""

    slug: str
    status: int
    title: str
    rule: str

    @property
    def type_uri(self) -> str:
        """The stable `type` member of the problem document."""
        return PROBLEM_BASE + self.slug


class Problem(Enum):
    """Every anchor intake rejection, in the order SAD 12.2 evaluates them."""

    CERTIFICATE_INVALID = ProblemSpec(
        "certificate-invalid", 401, "Client certificate invalid", "12.2 rule 1"
    )
    IDENTITY_MISMATCH = ProblemSpec(
        "identity-mismatch", 403, "Document site differs from certificate site", "12.2 rule 2"
    )
    SITE_NOT_ANCHORABLE = ProblemSpec(
        "site-not-anchorable", 409, "Site is not in an anchorable state", "12.2 rule 3"
    )
    PROTOCOL_VERSION = ProblemSpec(
        "protocol-version", 400, "Protocol major version not supported", "12.2 rule 4"
    )
    SIGNATURE_INVALID = ProblemSpec(
        "signature-invalid", 401, "Signature does not verify", "12.2 rule 5"
    )
    SEQUENCE_GAP = ProblemSpec("sequence-gap", 409, "Sequence skips ahead", "12.2 rule 6")
    SEQUENCE_REGRESSION = ProblemSpec(
        "sequence-regression", 409, "Sequence goes backwards", "12.2 rule 6"
    )
    CHAIN_DISCONTINUITY = ProblemSpec(
        "chain-discontinuity", 409, "Previous anchor hash does not match the head", "12.2 rule 7"
    )
    FORK_DETECTED = ProblemSpec(
        "fork-detected", 409, "A different entry hash for an anchored sequence", "12.2 rule 8"
    )
    CLOCK_SKEW = ProblemSpec("clock-skew", 400, "Site clock outside tolerance", "12.2 rule 9")
    RATE_LIMITED = ProblemSpec("rate-limited", 429, "Anchor rate limit exceeded", "threat M12")
    #: Added in 1.0.0 before release, after the v1 vectors were fixed. SAD
    #: 12.2 has no rule for a document that is not a head at all (a BLAKE3
    #: hash, a smuggled payload, AC-P13), and AC-P12 forbids folding it into
    #: another rejection.
    DOCUMENT_INVALID = ProblemSpec(
        "document-invalid", 400, "Document does not have the protocol's shape", "12.1, AC-P13"
    )
    #: Added in 1.0.0 before release. SAD 30: when chain verification fails the
    #: system is read only, and nothing is appended to a ledger that has just
    #: failed. Retryable: the agent keeps its heads and resubmits them in order
    #: once the estate is cleared.
    ESTATE_READ_ONLY = ProblemSpec(
        "estate-read-only", 503, "The estate is read only pending investigation", "SAD 30"
    )

    #: Model registration (SAD 13.1 `POST /v1/registry/models`). A release is
    #: registered only with proof it was anchored (SAD 11) and only from a site
    #: that can obtain a receipt (SAD 10, AC-X6).
    RELEASE_NOT_ANCHORED = ProblemSpec(
        "release-not-anchored", 409, "No countersigned anchor at the release's sequence", "SAD 11"
    )
    SITE_CANNOT_RELEASE = ProblemSpec(
        "site-cannot-release", 409, "The site is in a state that cannot release", "SAD 10, AC-X6"
    )

    @property
    def spec(self) -> ProblemSpec:
        """The problem's specification."""
        value: ProblemSpec = self.value
        return value
