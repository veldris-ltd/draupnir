"""The estate root: an RFC 6962 Merkle tree hash over site heads.

SAD 12.6 calls for "an estate root computed over" every site's head and does
not say how. This module fills that gap, and the choice is recorded in SPEC.md
as a G0 decision.

RFC 6962 section 2.1 was chosen over a flat hash of the list because it
admits an inclusion proof: a purchaser can later be shown that one site's head
is in a checkpoint without being shown every other site's head, which is the
shape open question MQ-4 is likely to need. It is also the tree a Rekor log
uses, so the back-fill Decision M2 keeps open stays a translation rather than a
redesign. A flat hash would have foreclosed both for no saving.

Leaves are hashed with a 0x00 prefix and interior nodes with 0x01, so a leaf
can never be presented as a node (second preimage resistance, RFC 6962
section 2.1).
"""

from __future__ import annotations

import hashlib
from collections.abc import Sequence

from shared_protocol.digest import Digest


def _leaf(data: bytes) -> bytes:
    return hashlib.sha256(b"\x00" + data).digest()


def _node(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + left + right).digest()


def _split(n: int) -> int:
    """The largest power of two strictly less than `n`. RFC 6962 section 2.1."""
    k = 1
    while k * 2 < n:
        k *= 2
    return k


def _mth(leaves: Sequence[bytes]) -> bytes:
    if not leaves:
        return hashlib.sha256(b"").digest()
    if len(leaves) == 1:
        return _leaf(leaves[0])
    k = _split(len(leaves))
    return _node(_mth(leaves[:k]), _mth(leaves[k:]))


def merkle_root(leaves: Sequence[bytes]) -> Digest:
    """Return the RFC 6962 Merkle tree hash of `leaves`, as a prefixed digest."""
    return Digest(f"sha256:{_mth(leaves).hex()}")
