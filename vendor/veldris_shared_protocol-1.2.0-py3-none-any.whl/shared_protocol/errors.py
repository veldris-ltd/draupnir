"""Errors raised at the type boundary.

Each names the field and the rule, never the offending value at length:
quoting a smuggled payload into an exception message would put it in a log,
which is where it was trying to go.
"""

from __future__ import annotations

from collections.abc import Sequence


class ProtocolError(ValueError):
    """Base class for every refusal this package makes."""


class DocumentError(ProtocolError):
    """A document, or a field in it, does not have the protocol's shape."""

    def __init__(self, field: str, why: str) -> None:
        """Record where in the document, and why."""
        self.field = field
        self.why = why
        super().__init__(f"{field}: {why}")


class ProtocolVersionError(ProtocolError):
    """A document declares a protocol major this package does not speak.

    SAD 12.2 rule 4 and AC-P10: rejected, never coerced, and the refusal names
    both versions so that the far end can tell an old agent from a new server.
    """

    def __init__(self, received: object, supported: Sequence[int]) -> None:
        """Record what arrived and what is spoken."""
        self.received = received
        self.supported = tuple(supported)
        spoken = ", ".join(str(v) for v in self.supported)
        super().__init__(
            f"protocol major {received!r} is not supported; this end speaks major {spoken}"
        )


class SignatureInvalidError(ProtocolError):
    """No signature in an envelope verified against a key the verifier trusts."""
