"""The versioned signature envelope. SAD 14.3.

One envelope carries one or more algorithm-tagged signatures over the same
canonical payload. A verifier accepts if any signature it can evaluate
verifies, so adding an algorithm is a new entry in the array rather than a
format change, and a receipt signed in 2026 still verifies in 2036 for a
verifier that knows only one of its algorithms (AC-R2).

Every signature covers the RFC 8785 canonical bytes of the document, and the
envelope names their digest as `payload_hash`, which binds an envelope to one
document: a verifier refuses an envelope whose hash does not match before it
looks at any signature.

`seal` takes a typed document and nothing else. There is no function in this
package that signs bytes a caller supplies, which is threat M7 (a signing
oracle) closed by type rather than by validation.
"""

from __future__ import annotations

from collections.abc import Collection, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Final, Protocol

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.asymmetric.mldsa import MLDSA65PrivateKey

from shared_protocol import fields
from shared_protocol.canonical import canonicalise
from shared_protocol.digest import Digest, parse_digest, sha256_digest
from shared_protocol.errors import DocumentError, SignatureInvalidError
from shared_protocol.keys import (
    KNOWN_ALGORITHMS,
    SIGNATURE_LENGTH,
    Algorithm,
    KeyPurpose,
    Keyring,
    PublicKey,
    b64decode,
    b64encode,
)
from shared_protocol.signable import AuthorityDocument, SignableDocument

#: The largest signature an envelope will carry for an algorithm this package
#: cannot evaluate. Generous enough for SLH-DSA; finite, so an unknown
#: algorithm is not an unbounded field.
MAX_UNKNOWN_SIGNATURE: Final = 64 * 1024
MAX_SIGNATURES: Final = 8


@dataclass(frozen=True, slots=True)
class Signature:
    """One algorithm-tagged signature."""

    alg: str
    key_id: str
    sig: bytes

    def to_wire(self) -> dict[str, Any]:
        """The wire shape. `sig` is standard padded base64."""
        return {"alg": self.alg, "key_id": self.key_id, "sig": b64encode(self.sig)}


@dataclass(frozen=True, slots=True)
class Envelope:
    """SAD 14.3: `{v, payload_hash, signatures: [{alg, key_id, sig}]}`."""

    payload_hash: Digest
    signatures: tuple[Signature, ...]
    v: int = fields.PROTOCOL_MAJOR

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {
            "v": self.v,
            "payload_hash": self.payload_hash,
            "signatures": [signature.to_wire() for signature in self.signatures],
        }

    @classmethod
    def from_wire(cls, value: object, *, tolerate_unknown_algorithms: bool = False) -> Envelope:
        """Parse an envelope.

        Strict by default: a signature under an algorithm this package does
        not know is refused, which is right for intake from a site. A
        long-lived verifier of receipts passes `tolerate_unknown_algorithms`,
        and such signatures are then carried, bounded in size, and skipped.
        """
        doc = fields.require_mapping(value, "envelope")
        v = fields.require_major(doc)
        payload_hash = parse_digest(fields.require(doc, "payload_hash"), field="payload_hash")
        entries = fields.require(doc, "signatures")
        if not isinstance(entries, list) or not entries:
            raise DocumentError("signatures", "expected a non-empty array")
        if len(entries) > MAX_SIGNATURES:
            raise DocumentError("signatures", f"at most {MAX_SIGNATURES} signatures")
        signatures: list[Signature] = []
        for index, entry in enumerate(entries):
            path = f"signatures[{index}]"
            item = fields.require_mapping(entry, path)
            alg = fields.algorithm_name(fields.require(item, "alg"), f"{path}.alg")
            key_id = fields.key_id(fields.require(item, "key_id"), f"{path}.key_id")
            if alg in KNOWN_ALGORITHMS:
                length: int | None = SIGNATURE_LENGTH[Algorithm(alg)]
            elif tolerate_unknown_algorithms:
                length = None
            else:
                raise DocumentError(f"{path}.alg", f"{alg!r} is not an algorithm this end speaks")
            sig = b64decode(fields.require(item, "sig"), f"{path}.sig", length=length)
            if len(sig) > MAX_UNKNOWN_SIGNATURE:
                raise DocumentError(f"{path}.sig", "too long to be a signature")
            signatures.append(Signature(alg=alg, key_id=key_id, sig=sig))
        pairs = [(s.alg, s.key_id) for s in signatures]
        if len(set(pairs)) != len(pairs):
            raise DocumentError("signatures", "one key signs once per algorithm")
        return cls(payload_hash=payload_hash, signatures=tuple(signatures), v=v)


class Signer(Protocol):
    """One algorithm under one key identifier.

    The primitive signs bytes, and is used only inside `seal`, which gives it
    canonical bytes of a typed document. MEGINGJORD's key provider (Prompt G4)
    implements this over PKCS#11 and exposes only `seal`-shaped calls.
    """

    @property
    def alg(self) -> Algorithm:
        """The algorithm."""
        ...

    @property
    def key_id(self) -> str:
        """The identifier the signature is recorded under."""
        ...

    def sign(self, message: bytes) -> bytes:
        """The raw signature over `message`."""
        ...


class Ed25519Signer:
    """An in-memory Ed25519 signer, for sites, tests and development."""

    alg: Final = Algorithm.ED25519

    def __init__(self, key_id: str, private_key: Ed25519PrivateKey) -> None:
        """Hold the key under its identifier."""
        self.key_id = fields.key_id(key_id, "key_id")
        self._private = private_key

    @classmethod
    def from_seed(cls, key_id: str, seed: bytes) -> Ed25519Signer:
        """From the 32-byte RFC 8032 seed."""
        return cls(key_id, Ed25519PrivateKey.from_private_bytes(seed))

    def public_key(self) -> PublicKey:
        """The public half."""
        return PublicKey(self.alg, self._private.public_key().public_bytes_raw())

    def sign(self, message: bytes) -> bytes:
        """Ed25519 is deterministic: one message, one signature."""
        return self._private.sign(message)


class MLDSA65Signer:
    """An in-memory ML-DSA-65 signer (FIPS 204), for tests and development.

    Signing is hedged, so two signatures over one message differ. Golden
    vectors for this algorithm are therefore verified, never reproduced.
    """

    alg: Final = Algorithm.ML_DSA_65

    def __init__(self, key_id: str, private_key: MLDSA65PrivateKey) -> None:
        """Hold the key under its identifier."""
        self.key_id = fields.key_id(key_id, "key_id")
        self._private = private_key

    @classmethod
    def from_seed(cls, key_id: str, seed: bytes) -> MLDSA65Signer:
        """From the 32-byte FIPS 204 seed."""
        return cls(key_id, MLDSA65PrivateKey.from_seed_bytes(seed))

    def public_key(self) -> PublicKey:
        """The public half."""
        return PublicKey(self.alg, self._private.public_key().public_bytes_raw())

    def sign(self, message: bytes) -> bytes:
        """An ML-DSA-65 signature with an empty context string."""
        return self._private.sign(message)


def seal(document: SignableDocument, signers: Sequence[Signer]) -> Envelope:
    """Sign a typed document with every signer, in one envelope.

    A receipt or checkpoint names its own key and algorithms, and the signers
    must be exactly those: a receipt that says it was signed with ML-DSA-65
    and was not is refused here rather than discovered by a purchaser.
    """
    if not signers:
        raise DocumentError("signatures", "an envelope carries at least one signature")
    if not isinstance(document, SignableDocument):
        msg = f"{type(document).__name__} is not a document kind the protocol signs"
        raise TypeError(msg)
    if isinstance(document, AuthorityDocument):
        named = {(document.key_id, alg) for alg in document.algorithms}
        offered = {(signer.key_id, str(signer.alg)) for signer in signers}
        if named != offered:
            raise DocumentError(
                "signatures",
                "the signers must be exactly the key and algorithms the document names",
            )
    message = document.canonical()
    return Envelope(
        payload_hash=sha256_digest(message),
        signatures=tuple(
            Signature(alg=str(signer.alg), key_id=signer.key_id, sig=signer.sign(message))
            for signer in signers
        ),
    )


@dataclass(frozen=True, slots=True)
class Verified:
    """Which signature verified."""

    alg: Algorithm
    key_id: str
    payload_hash: Digest


def verify(
    document: Mapping[str, Any],
    envelope: Envelope,
    keyring: Keyring,
    *,
    purpose: KeyPurpose,
    key_id: str | None = None,
    algorithms: Collection[Algorithm] = tuple(Algorithm),
) -> Verified:
    """Verify `envelope` over a document as received. Raise if nothing verifies.

    `document` is the parsed JSON exactly as it arrived (see
    `canonical.loads`), not a re-rendering of a typed object, so a field added
    by a later minor version is covered by the check.

    Accepts if any signature verifies whose algorithm is in `algorithms`, whose
    key the keyring trusts for `purpose`, and, when `key_id` is given, whose
    key is that one. Passing a single algorithm models a verifier that knows
    only that one (AC-R2).
    """
    message = canonicalise(document)
    payload_hash = sha256_digest(message)
    if envelope.payload_hash != payload_hash:
        msg = "the envelope is over a different document: payload_hash does not match"
        raise SignatureInvalidError(msg)

    allowed = {str(alg) for alg in algorithms}
    for signature in envelope.signatures:
        if signature.alg not in allowed:
            continue
        if key_id is not None and signature.key_id != key_id:
            continue
        published = keyring.get(signature.key_id)
        if published is None or published.purpose is not purpose:
            continue
        public = published.for_algorithm(Algorithm(signature.alg))
        if public is not None and public.verify(signature.sig, message):
            return Verified(Algorithm(signature.alg), signature.key_id, payload_hash)

    msg = (
        f"no signature verified against a trusted {purpose} key"
        + (f" {key_id}" if key_id else "")
        + f" under {', '.join(sorted(allowed))}"
    )
    raise SignatureInvalidError(msg)
