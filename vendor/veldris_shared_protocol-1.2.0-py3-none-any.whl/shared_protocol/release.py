"""Model release metadata, pushed by a site. SAD 13.1 `POST /v1/registry/models`.

After a successful release, a site pushes what was released and the anchored
ledger sequence the release was recorded at. Metadata and URIs only: no field
can carry an artefact (MD-2). Every string is bounded and matched, the
manifest is a digest of the release package, not the package, and the URIs
point at objects the forge holds.

Signed by the site's key, like an anchor head, so that a release record is
attributable to the site that made it (threat M2).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Final
from uuid import UUID

from shared_protocol import fields
from shared_protocol.digest import Digest, parse_digest
from shared_protocol.documents import _Document
from shared_protocol.errors import DocumentError

RELEASE_KIND: Final = "megingjord.model-release"

_MODEL_NAME: Final = re.compile(r"^[a-z0-9][a-z0-9.-]{0,127}\Z")
_VERSION: Final = re.compile(r"^[0-9A-Za-z][0-9A-Za-z.+-]{0,63}\Z")
_JURISDICTION: Final = re.compile(r"^[A-Z]{3}\Z")
_TIER: Final = re.compile(r"^[a-z][a-z0-9-]{0,31}\Z")
_URI: Final = re.compile(r"^(minio|s3|https)://[A-Za-z0-9._~/:@%+-]{1,500}\Z")
URI_FIELDS: Final = ("card_uri", "sbom_uri", "lineage_uri", "training_summary_uri")


def _match(value: object, path: str, pattern: re.Pattern[str], what: str) -> str:
    if not isinstance(value, str) or not pattern.match(value):
        raise DocumentError(path, f"expected {what}")
    return value


@dataclass(frozen=True, slots=True)
class ModelRelease(_Document):
    """What a site released, and the anchored sequence it was recorded at."""

    site_id: UUID
    name: str
    version: str
    jurisdiction: str
    tier: str
    manifest_sha256: Digest
    anchor_seq: int
    card_uri: str
    sbom_uri: str
    lineage_uri: str
    training_summary_uri: str
    released_at: datetime
    v: int = fields.PROTOCOL_MAJOR
    kind: str = field(default=RELEASE_KIND)

    def __post_init__(self) -> None:
        """Refuse a record that could carry anything but metadata."""
        if self.v not in fields.SUPPORTED_MAJORS:
            fields.require_major({"v": self.v})
        if self.kind != RELEASE_KIND:
            raise DocumentError("kind", f"expected {RELEASE_KIND!r}")
        _match(self.name, "name", _MODEL_NAME, "a lowercase model name")
        _match(self.version, "version", _VERSION, "a version of at most 64 characters")
        _match(self.jurisdiction, "jurisdiction", _JURISDICTION, "an ISO 3166 alpha-3 code")
        _match(self.tier, "tier", _TIER, "a short lowercase tier")
        parse_digest(self.manifest_sha256, field="manifest_sha256")
        fields.integer(self.anchor_seq, "anchor_seq")
        for name in URI_FIELDS:
            _match(getattr(self, name), name, _URI, "a minio://, s3:// or https:// URI")
        object.__setattr__(
            self, "released_at", fields.check_instant(self.released_at, "released_at")
        )

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {
            "v": self.v,
            "kind": self.kind,
            "site_id": str(self.site_id),
            "name": self.name,
            "version": self.version,
            "jurisdiction": self.jurisdiction,
            "tier": self.tier,
            "manifest_sha256": self.manifest_sha256,
            "anchor_seq": self.anchor_seq,
            "card_uri": self.card_uri,
            "sbom_uri": self.sbom_uri,
            "lineage_uri": self.lineage_uri,
            "training_summary_uri": self.training_summary_uri,
            "released_at": fields.render_instant(self.released_at),
        }

    @classmethod
    def from_wire(cls, value: object) -> ModelRelease:
        """Parse a received release record."""
        doc = fields.require_mapping(value, "$")
        v = fields.require_major(doc)
        if fields.require(doc, "kind") != RELEASE_KIND:
            raise DocumentError("kind", f"expected {RELEASE_KIND!r}")
        return cls(
            v=v,
            site_id=fields.uuid(fields.require(doc, "site_id"), "site_id"),
            name=fields.require(doc, "name"),
            version=fields.require(doc, "version"),
            jurisdiction=fields.require(doc, "jurisdiction"),
            tier=fields.require(doc, "tier"),
            manifest_sha256=parse_digest(
                fields.require(doc, "manifest_sha256"), field="manifest_sha256"
            ),
            anchor_seq=fields.integer(fields.require(doc, "anchor_seq"), "anchor_seq"),
            card_uri=fields.require(doc, "card_uri"),
            sbom_uri=fields.require(doc, "sbom_uri"),
            lineage_uri=fields.require(doc, "lineage_uri"),
            training_summary_uri=fields.require(doc, "training_summary_uri"),
            released_at=fields.timestamp(fields.require(doc, "released_at"), "released_at"),
        )
