"""Algorithms, published public keys and the verifier's keyring.

SAD 14.1: Ed25519 now, with ML-DSA-65 carried alongside it from Release 1 so
that the post quantum migration adds nothing to the format. SAD 14.2 and
Decision M5: three operational keys with three purposes, plus each site's own
key. A published key names its purpose, and verification requires the purpose
the document calls for, so a receipt cannot be verified against the policy key
even though both are "a MEGINGJORD key".
"""

from __future__ import annotations

import base64
import binascii
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Final

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.mldsa import MLDSA65PublicKey

from shared_protocol import fields
from shared_protocol.errors import DocumentError


class Algorithm(StrEnum):
    """Signature algorithms this package can evaluate."""

    ED25519 = "ed25519"
    ML_DSA_65 = "ml-dsa-65"


KNOWN_ALGORITHMS: Final = frozenset(alg.value for alg in Algorithm)

#: Raw public key lengths in bytes. Ed25519: RFC 8032. ML-DSA-65: FIPS 204.
PUBLIC_KEY_LENGTH: Final[Mapping[Algorithm, int]] = {
    Algorithm.ED25519: 32,
    Algorithm.ML_DSA_65: 1952,
}

#: Raw signature lengths in bytes. Exact, so a signature field cannot carry
#: anything but a signature (AC-P13).
SIGNATURE_LENGTH: Final[Mapping[Algorithm, int]] = {
    Algorithm.ED25519: 64,
    Algorithm.ML_DSA_65: 3309,
}


class KeyPurpose(StrEnum):
    """What a key is allowed to assert. Decision M5."""

    SITE = "site"
    ANCHOR = "anchor"
    POLICY = "policy"
    CHECKPOINT = "checkpoint"


PUBLIC_KEY_KIND: Final = "megingjord.public-key"


def b64decode(value: object, field: str, *, length: int | None = None) -> bytes:
    """Standard base64 with padding, strictly. Optionally an exact decoded length."""
    if not isinstance(value, str):
        raise DocumentError(field, "expected base64 text")
    try:
        raw = base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as error:
        raise DocumentError(field, "not valid base64") from error
    if base64.b64encode(raw).decode("ascii") != value:
        raise DocumentError(field, "base64 must be in its one padded form")
    if length is not None and len(raw) != length:
        raise DocumentError(field, f"expected {length} bytes, got {len(raw)}")
    return raw


def b64encode(raw: bytes) -> str:
    """Standard base64 with padding."""
    return base64.b64encode(raw).decode("ascii")


@dataclass(frozen=True, slots=True)
class PublicKey:
    """One algorithm's public half under a key identifier."""

    alg: Algorithm
    raw: bytes

    def __post_init__(self) -> None:
        """Refuse a key of the wrong size for its algorithm."""
        if len(self.raw) != PUBLIC_KEY_LENGTH[self.alg]:
            raise DocumentError(
                "public_key", f"{self.alg} keys are {PUBLIC_KEY_LENGTH[self.alg]} bytes"
            )

    def verify(self, signature: bytes, message: bytes) -> bool:
        """Whether `signature` is this key's signature over `message`."""
        try:
            if self.alg is Algorithm.ED25519:
                Ed25519PublicKey.from_public_bytes(self.raw).verify(signature, message)
            else:
                MLDSA65PublicKey.from_public_bytes(self.raw).verify(signature, message)
        except InvalidSignature:
            return False
        return True

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {"alg": str(self.alg), "public_key": b64encode(self.raw)}


@dataclass(frozen=True, slots=True)
class PublishedKey:
    """The document a verifier holds: `published/meg-anchor-2026-01.pub` (SAD 29).

    One key identifier may carry several algorithms, which is how the anchor,
    policy and checkpoint keys carry Ed25519 and ML-DSA-65 together.
    """

    key_id: str
    purpose: KeyPurpose
    keys: tuple[PublicKey, ...]
    v: int = fields.PROTOCOL_MAJOR

    def __post_init__(self) -> None:
        """Refuse an empty or ambiguous key document."""
        fields.key_id(self.key_id, "key_id")
        if not self.keys:
            raise DocumentError("keys", "a published key carries at least one algorithm")
        algs = [key.alg for key in self.keys]
        if len(set(algs)) != len(algs):
            raise DocumentError("keys", "an algorithm appears twice")

    def for_algorithm(self, alg: Algorithm) -> PublicKey | None:
        """This key's public half for `alg`, if it has one."""
        return next((key for key in self.keys if key.alg is alg), None)

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {
            "v": self.v,
            "kind": PUBLIC_KEY_KIND,
            "key_id": self.key_id,
            "purpose": str(self.purpose),
            "keys": [key.to_wire() for key in self.keys],
        }

    @classmethod
    def from_wire(cls, value: object) -> PublishedKey:
        """Parse a published key, ignoring unknown fields and unknown algorithms.

        An algorithm this verifier cannot evaluate is skipped rather than
        refused: a key published in 2036 with a third algorithm must still be
        usable by a verifier that knows only Ed25519 (SAD 14.3).
        """
        document = fields.require_mapping(value, "$")
        v = fields.require_major(document)
        if fields.require(document, "kind") != PUBLIC_KEY_KIND:
            raise DocumentError("kind", f"expected {PUBLIC_KEY_KIND!r}")
        purpose_raw = fields.require(document, "purpose")
        try:
            purpose = KeyPurpose(purpose_raw)
        except ValueError as error:
            raise DocumentError("purpose", "not a known key purpose") from error
        entries = fields.require(document, "keys")
        if not isinstance(entries, list):
            raise DocumentError("keys", "expected an array")
        keys: list[PublicKey] = []
        for index, entry in enumerate(entries):
            item = fields.require_mapping(entry, f"keys[{index}]")
            alg_name = fields.algorithm_name(fields.require(item, "alg"), f"keys[{index}].alg")
            if alg_name not in KNOWN_ALGORITHMS:
                continue
            alg = Algorithm(alg_name)
            raw = b64decode(
                fields.require(item, "public_key"),
                f"keys[{index}].public_key",
                length=PUBLIC_KEY_LENGTH[alg],
            )
            keys.append(PublicKey(alg, raw))
        return cls(
            key_id=fields.key_id(fields.require(document, "key_id"), "key_id"),
            purpose=purpose,
            keys=tuple(keys),
            v=v,
        )


class Keyring:
    """The public keys a verifier trusts, by identifier."""

    def __init__(self, keys: Iterable[PublishedKey] = ()) -> None:
        """Index `keys` by identifier, refusing a duplicate identifier."""
        self._keys: dict[str, PublishedKey] = {}
        for key in keys:
            if key.key_id in self._keys:
                raise DocumentError("key_id", f"{key.key_id} appears twice in the keyring")
            self._keys[key.key_id] = key

    def get(self, key_id: str) -> PublishedKey | None:
        """The published key under `key_id`, if trusted."""
        return self._keys.get(key_id)

    def __contains__(self, key_id: object) -> bool:
        """Whether `key_id` is trusted."""
        return key_id in self._keys
