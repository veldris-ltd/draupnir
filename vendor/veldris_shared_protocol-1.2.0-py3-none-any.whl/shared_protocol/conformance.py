"""The golden vectors as a conformance suite a consumer runs. SAD 33.3.

The vectors ship inside the package, and `shared-protocol conformance` checks
the installed implementation against them. GULLINBURSTI and MEGINGJORD each
run it in their own pipeline, alongside their own checked-in copy of the
vectors, so a release of this package that disagrees with its own history
fails at both ends.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from importlib import resources
from pathlib import Path
from typing import Any

from shared_protocol.attestation import Attestation
from shared_protocol.canonical import CanonicalisationError, canonicalise, loads
from shared_protocol.digest import sha256_digest
from shared_protocol.documents import AnchorHead, AnchorReceipt, Checkpoint
from shared_protocol.envelope import Envelope, verify
from shared_protocol.errors import ProtocolError
from shared_protocol.keys import Algorithm, KeyPurpose, Keyring, PublishedKey
from shared_protocol.merkle import merkle_root
from shared_protocol.policy import PolicyAcknowledgement, PolicyDocument
from shared_protocol.problems import Problem
from shared_protocol.release import ModelRelease

#: The vector sets this release ships, oldest first. Every one must keep passing.
SETS: tuple[str, ...] = ("v1", "v1.1", "v1.2")

_TYPES: dict[str, Callable[[object], Any]] = {
    "anchor-head": AnchorHead.from_wire,
    "anchor-receipt": AnchorReceipt.from_wire,
    "checkpoint": Checkpoint.from_wire,
    "policy": PolicyDocument.from_wire,
    "policy-acknowledgement": PolicyAcknowledgement.from_wire,
    "model-release": ModelRelease.from_wire,
    "attestation": Attestation.from_wire,
}


def _load(directory: Path | str, name: str) -> Any:
    """A vector file from a directory, or from a shipped set by name. None if absent."""
    if isinstance(directory, Path):
        path = directory / name
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
    resource = resources.files("shared_protocol").joinpath("golden", directory, name)
    return json.loads(resource.read_text("utf-8")) if resource.is_file() else None


def run(directory: Path | None = None) -> list[str]:
    """Check a vector set, or every shipped set. Each failure described; empty is a pass."""
    if directory is not None:
        return _run(directory)
    return [f"{name}: {failure}" for name in SETS for failure in _run(name)]


def _run(directory: Path | str) -> list[str]:
    failures: list[str] = []

    canon = _load(directory, "canonicalisation.json") or {"cases": [], "rejects": []}
    for case in canon["cases"]:
        try:
            got = canonicalise(loads(case["input"]))
        except CanonicalisationError as error:
            failures.append(f"canonicalisation {case['name']}: refused ({error})")
            continue
        if got.hex() != case["canonical_hex"] or sha256_digest(got) != case["sha256"]:
            failures.append(f"canonicalisation {case['name']}: bytes differ")
    for case in canon["rejects"]:
        try:
            canonicalise(loads(case["input"]))
        except CanonicalisationError:
            continue
        failures.append(f"canonicalisation reject {case['name']}: accepted")

    keys = _load(directory, "keys.json")["keys"]
    keyring = Keyring(PublishedKey.from_wire(key["published"]) for key in keys)
    for case in _load(directory, "documents.json")["cases"]:
        name = case["name"]
        canonical = canonicalise(case["document"])
        if canonical.decode("utf-8") != case["canonical"]:
            failures.append(f"document {name}: canonical bytes differ")
            continue
        if sha256_digest(canonical) != case["payload_hash"]:
            failures.append(f"document {name}: payload hash differs")
        try:
            parsed = _TYPES[case["kind"]](case["document"])
            same = parsed.canonical().decode("utf-8") == case["canonical"]
            if same is not case["roundtrips"]:
                failures.append(f"document {name}: typed round trip changed")
            envelope = Envelope.from_wire(case["envelope"])
            for sig in case["envelope"]["signatures"]:
                verify(
                    case["document"],
                    envelope,
                    keyring,
                    purpose=KeyPurpose(case["purpose"]),
                    algorithms=[Algorithm(sig["alg"])],
                )
        except ProtocolError as error:
            failures.append(f"document {name}: {error}")

    for case in _load(directory, "document_rejects.json")["cases"]:
        try:
            _TYPES[case["kind"]](case["document"])
        except ProtocolError:
            continue
        failures.append(f"document reject {case['name']}: accepted")

    for case in (_load(directory, "merkle.json") or {"cases": []})["cases"]:
        leaves = [bytes.fromhex(leaf) for leaf in case["leaves_hex"]]
        if merkle_root(leaves) != case["root"]:
            failures.append(f"merkle root over {len(leaves)} leaves differs")

    # A later version may add problem types; it may not change or drop one.
    current = {
        p.name: {
            "name": p.name,
            "slug": p.spec.slug,
            "status": p.spec.status,
            "type": p.spec.type_uri,
        }
        for p in Problem
    }
    for fixed in _load(directory, "problems.json")["problems"]:
        if current.get(fixed["name"]) != fixed:
            failures.append(f"problem type {fixed['name']} changed or removed")

    return failures
