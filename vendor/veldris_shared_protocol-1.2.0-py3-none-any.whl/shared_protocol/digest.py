"""Algorithm-prefixed digests.

SAD 14.1: entry and anchor hashes carry their algorithm as a prefix in the
value. Open question MQ-6 is settled as SHA-256, because DRAUPNIR's forge
ledger is SHA-256 and the two hash-chained ledgers must agree. A digest on the
wire is therefore `sha256:` followed by 64 lowercase hex characters, and
nothing else is accepted in protocol major 1.

The prefix is what makes a later change of algorithm a new accepted prefix
rather than a reinterpretation of old values.
"""

from __future__ import annotations

import hashlib
import re
from enum import StrEnum
from typing import Final, NewType

from shared_protocol.errors import DocumentError


class HashAlgorithm(StrEnum):
    """Hash algorithms a digest may name. Major 1 has exactly one."""

    SHA256 = "sha256"


#: A validated digest string, `sha256:<64 lowercase hex>`.
Digest = NewType("Digest", str)

DIGEST_PATTERN: Final = re.compile(r"^sha256:[0-9a-f]{64}\Z")


class DigestError(DocumentError):
    """Raised when a value is not a digest in the protocol's form."""


def parse_digest(value: object, *, field: str = "digest") -> Digest:
    """Return `value` as a `Digest`, or raise naming the field."""
    if not isinstance(value, str) or not DIGEST_PATTERN.match(value):
        shown = value if isinstance(value, str) and len(value) <= 80 else type(value).__name__
        raise DigestError(
            field,
            f"{shown!r} is not a digest. A digest is 'sha256:' followed by "
            "64 lowercase hex characters (SAD 14.1, MQ-6)",
        )
    return Digest(value)


def sha256_digest(data: bytes) -> Digest:
    """Return the prefixed SHA-256 of `data`."""
    return Digest(f"{HashAlgorithm.SHA256}:{hashlib.sha256(data).hexdigest()}")


def digest_bytes(digest: Digest) -> bytes:
    """Return the raw 32 bytes a digest names."""
    return bytes.fromhex(digest.split(":", 1)[1])
