"""Canonical JSON. RFC 8785, the JSON Canonicalization Scheme.

SAD 12.1: "The document is canonicalised before signing: JSON Canonicalization
Scheme, sorted keys, no insignificant whitespace, UTF-8."

Canonicalisation is where a signature protocol quietly breaks. A change here
that looks harmless invalidates every signature ever made over the old bytes,
which is why the golden vectors in `golden/v1/` are fixed data and why a
planted change to this module fails the build (Decision M9, AC-P14).

The serialiser is written out rather than delegated to `json.dumps`, because
two of RFC 8785's rules differ from anything `json.dumps` can be configured to
do, and a reader auditing this file should not have to know which flags happen
to coincide with the RFC:

- Object members are sorted by their names as UTF-16 code units (RFC 8785
  section 3.2.3), not by code point. The two orders disagree for names that
  mix characters above U+FFFF with characters in U+E000 to U+FFFF.
- Strings are escaped exactly as ECMAScript `JSON.stringify` escapes them
  (section 3.2.2.2): the two-character escapes for `\\b \\f \\n \\r \\t \\" \\\\`,
  `\\u00xx` in lowercase hex for every other control character, and every other
  character as literal UTF-8.

Numbers are the one deliberate restriction. RFC 8785 serialises any IEEE 754
double using the ECMAScript number-to-string algorithm. The protocol has no
field that is not an integer, so this implementation accepts integers in the
I-JSON safe range (RFC 7493, plus or minus 2**53 - 1) and refuses everything
else. Within that domain the output is exactly RFC 8785. A non-integer that
reached a signed document would be a protocol defect, and refusing it is
cheaper than proving a float formatter correct.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping, Sequence
from typing import Any, Final

#: The largest magnitude an integer may have and survive a round trip through
#: an IEEE 754 double, which is what every JSON parser outside Python uses.
MAX_SAFE_INTEGER: Final = 2**53 - 1

_SHORT_ESCAPES: Final[dict[str, str]] = {
    '"': '\\"',
    "\\": "\\\\",
    "\b": "\\b",
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "\t": "\\t",
}


class CanonicalisationError(ValueError):
    """Raised when a value has no canonical form under this scheme."""


#: Every character `_string` would escape or refuse. A string with none of
#: them is its own canonical form, and most protocol strings (hashes,
#: identifiers, base64 signatures) are such strings, so they skip the
#: per-character walk. The output is identical either way; the golden vectors
#: and the canary hold this to that.
_SPECIAL: Final = re.compile('[\\x00-\\x1f"\\\\\\ud800-\\udfff]')


def _string(value: str) -> str:
    if not _SPECIAL.search(value):
        return f'"{value}"'
    out: list[str] = ['"']
    for char in value:
        code = ord(char)
        if char in _SHORT_ESCAPES:
            out.append(_SHORT_ESCAPES[char])
        elif code < 0x20:
            out.append(f"\\u{code:04x}")
        elif 0xD800 <= code <= 0xDFFF:
            # A lone surrogate has no UTF-8 encoding. ECMAScript would escape
            # it, but a document carrying one is not one a site produced on
            # purpose, so it is refused rather than given a form.
            msg = f"the string contains a lone surrogate U+{code:04X}, which has no UTF-8 form"
            raise CanonicalisationError(msg)
        else:
            out.append(char)
    out.append('"')
    return "".join(out)


def _utf16_key(name: str) -> bytes:
    """Sort key giving RFC 8785's order: UTF-16 code units, compared as unsigned."""
    return name.encode("utf-16-be", "surrogatepass")


def _value(value: Any, path: str) -> str:
    # bool before int: in Python `True` is an `int`, and `1` is not `true`.
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        if not -MAX_SAFE_INTEGER <= value <= MAX_SAFE_INTEGER:
            msg = f"{path} is {value}, outside the I-JSON safe integer range"
            raise CanonicalisationError(msg)
        return str(value)
    if isinstance(value, float):
        msg = f"{path} is a non-integer number; the protocol carries integers only"
        raise CanonicalisationError(msg)
    if isinstance(value, str):
        return _string(value)
    if isinstance(value, Mapping):
        members: list[str] = []
        for name in sorted(value, key=_check_name(path)):
            members.append(f"{_string(name)}:{_value(value[name], f'{path}.{name}')}")
        return "{" + ",".join(members) + "}"
    if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
        items = [_value(item, f"{path}[{index}]") for index, item in enumerate(value)]
        return "[" + ",".join(items) + "]"
    msg = f"{path} is a {type(value).__name__}, which JSON has no form for"
    raise CanonicalisationError(msg)


def _check_name(path: str) -> Any:
    def key(name: object) -> bytes:
        if not isinstance(name, str):
            msg = f"{path} has a member name {name!r} that is not a string"
            raise CanonicalisationError(msg)
        return _utf16_key(name)

    return key


def canonicalise(value: Any) -> bytes:
    """Return the RFC 8785 canonical UTF-8 bytes of a JSON value.

    These bytes, and nothing re-rendered from them, are what every signature
    and every `payload_hash` in the protocol covers.
    """
    return _value(value, "$").encode("utf-8")


def _reject_constant(name: str) -> Any:
    msg = f"{name} is not a JSON number this protocol accepts"
    raise CanonicalisationError(msg)


def _reject_float(text: str) -> Any:
    msg = f"{text} is a non-integer number; the protocol carries integers only"
    raise CanonicalisationError(msg)


def _no_duplicates(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for name, item in pairs:
        if name in result:
            # RFC 8785 section 3.1 requires unique names. A parser that kept
            # the last value would let a signed document mean two things.
            msg = f"the member name {name!r} appears twice"
            raise CanonicalisationError(msg)
        result[name] = item
    return result


def loads(text: str | bytes) -> Any:
    """Parse received JSON strictly, for verification.

    Refuses duplicate member names, NaN and the infinities, and any number
    that is not an integer, so that a document parsed here has exactly one
    canonical form.
    """
    return json.loads(
        text,
        object_pairs_hook=_no_duplicates,
        parse_float=_reject_float,
        parse_constant=_reject_constant,
    )
