"""Offline receipt and checkpoint verification. AC-R1.

A receipt must verify using only the document, its signature and the
published key, with no MEGINGJORD code in the path. This module is that path:
it depends on this package and `cryptography`, holds no state and makes no
network call. The estate console's verify action (E13, AC-U7) and a
purchaser's diligence run the same function.

A signed document travels as one JSON file, `{"document": ..., "envelope":
...}`, so that a receipt can be embedded in a DRAUPNIR release package and
handed over as a single artefact.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from shared_protocol import fields
from shared_protocol.attestation import Attestation
from shared_protocol.canonical import loads
from shared_protocol.documents import AnchorReceipt, Checkpoint
from shared_protocol.envelope import Envelope, Verified, verify
from shared_protocol.keys import KeyPurpose, Keyring, PublishedKey
from shared_protocol.policy import PolicyDocument


@dataclass(frozen=True, slots=True)
class SignedDocument:
    """A document as received, and the envelope over it."""

    document: dict[str, Any]
    envelope: Envelope

    def to_wire(self) -> dict[str, Any]:
        """The single-file form."""
        return {"document": self.document, "envelope": self.envelope.to_wire()}

    @classmethod
    def from_json(cls, text: str | bytes) -> SignedDocument:
        """Parse the single-file form strictly."""
        doc = fields.require_mapping(loads(text), "$")
        document = dict(fields.require_mapping(fields.require(doc, "document"), "document"))
        envelope = Envelope.from_wire(
            fields.require(doc, "envelope"), tolerate_unknown_algorithms=True
        )
        return cls(document=document, envelope=envelope)


@dataclass(frozen=True, slots=True)
class VerifiedReceipt:
    """A receipt whose signature verified, and which signature it was."""

    receipt: AnchorReceipt
    verified: Verified


@dataclass(frozen=True, slots=True)
class VerifiedCheckpoint:
    """A checkpoint whose signature verified."""

    checkpoint: Checkpoint
    verified: Verified


def load_keyring(*published: str | bytes) -> Keyring:
    """A keyring from published key files' contents."""
    return Keyring(PublishedKey.from_wire(loads(text)) for text in published)


def verify_receipt(signed: SignedDocument, keyring: Keyring) -> VerifiedReceipt:
    """Verify a receipt against an anchor key, then parse it.

    The signature is checked first, over the document as received, and must
    come from the key the receipt itself names, under the anchor purpose.
    """
    named = fields.key_id(signed.document.get("key_id"), "key_id")
    verified = verify(
        signed.document, signed.envelope, keyring, purpose=KeyPurpose.ANCHOR, key_id=named
    )
    return VerifiedReceipt(AnchorReceipt.from_wire(signed.document), verified)


def verify_checkpoint(signed: SignedDocument, keyring: Keyring) -> VerifiedCheckpoint:
    """Verify a checkpoint against a checkpoint key, then parse it."""
    named = fields.key_id(signed.document.get("key_id"), "key_id")
    verified = verify(
        signed.document, signed.envelope, keyring, purpose=KeyPurpose.CHECKPOINT, key_id=named
    )
    return VerifiedCheckpoint(Checkpoint.from_wire(signed.document), verified)


@dataclass(frozen=True, slots=True)
class VerifiedPolicy:
    """A policy version whose signature verified under a policy key."""

    policy: PolicyDocument
    verified: Verified


def verify_policy(signed: SignedDocument, keyring: Keyring) -> VerifiedPolicy:
    """The site's check before adopting a policy (threat M11, AC-M11).

    Verified against the key the document names, under the POLICY purpose: a
    document signed by the anchor key, the checkpoint key or any key the site
    does not hold as a policy key is refused, however valid its signature.
    """
    named = fields.key_id(signed.document.get("key_id"), "key_id")
    verified = verify(
        signed.document, signed.envelope, keyring, purpose=KeyPurpose.POLICY, key_id=named
    )
    return VerifiedPolicy(PolicyDocument.from_wire(signed.document), verified)


@dataclass(frozen=True, slots=True)
class VerifiedAttestation:
    """An attestation whose signature verified under a checkpoint key."""

    attestation: Attestation
    verified: Verified


def verify_attestation(signed: SignedDocument, keyring: Keyring) -> VerifiedAttestation:
    """Verify an attestation against the checkpoint key it names, then parse it."""
    named = fields.key_id(signed.document.get("key_id"), "key_id")
    verified = verify(
        signed.document, signed.envelope, keyring, purpose=KeyPurpose.CHECKPOINT, key_id=named
    )
    return VerifiedAttestation(Attestation.from_wire(signed.document), verified)
