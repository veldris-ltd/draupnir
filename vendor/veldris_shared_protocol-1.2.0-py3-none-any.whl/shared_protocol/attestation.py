"""The attestation: MEGINGJORD's signed statement of what it verified. SAD 13.2, F4.

Journey F4 ends in "export signed attestation bundle". The attestation is the
signed part (G5 decision): MEGINGJORD states that it verified its estate
ledger from genesis to a head, at an instant, and names the checkpoint the
auditor selected. It is signed by the CHECKPOINT key, because, like a
checkpoint, it asserts the state of the estate (Decision M5).

It travels in a bundle with the signed checkpoint it names, any receipts the
auditor asked for, and the published keys, so that every claim in the bundle
verifies offline with this package and nothing else (`verify_attestation`,
`verify_checkpoint`, `verify_receipt`).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Final

from shared_protocol import fields
from shared_protocol.digest import Digest, parse_digest
from shared_protocol.documents import _Document
from shared_protocol.errors import DocumentError

ATTESTATION_KIND: Final = "megingjord.attestation"


@dataclass(frozen=True, slots=True)
class Attestation(_Document):
    """The estate ledger verified, to a head, at an instant; and a checkpoint named."""

    verified_at: datetime
    ledger_entries: int
    ledger_head_seq: int
    ledger_head_hash: Digest
    checkpoint_seq: int
    checkpoint_root: Digest
    key_id: str
    algorithms: tuple[str, ...]
    v: int = fields.PROTOCOL_MAJOR
    kind: str = field(default=ATTESTATION_KIND)

    def __post_init__(self) -> None:
        """Refuse an attestation that does not say exactly what was verified."""
        if self.v not in fields.SUPPORTED_MAJORS:
            fields.require_major({"v": self.v})
        if self.kind != ATTESTATION_KIND:
            raise DocumentError("kind", f"expected {ATTESTATION_KIND!r}")
        object.__setattr__(
            self, "verified_at", fields.check_instant(self.verified_at, "verified_at")
        )
        fields.integer(self.ledger_entries, "ledger_entries", minimum=1)
        fields.integer(self.ledger_head_seq, "ledger_head_seq")
        if self.ledger_head_seq != self.ledger_entries - 1:
            raise DocumentError(
                "ledger_head_seq", "a ledger verified from genesis ends at entries - 1"
            )
        parse_digest(self.ledger_head_hash, field="ledger_head_hash")
        fields.integer(self.checkpoint_seq, "checkpoint_seq")
        parse_digest(self.checkpoint_root, field="checkpoint_root")
        fields.key_id(self.key_id, "key_id")
        if not self.algorithms or len(set(self.algorithms)) != len(self.algorithms):
            raise DocumentError("algorithms", "expected distinct algorithm names")
        for i, name in enumerate(self.algorithms):
            fields.algorithm_name(name, f"algorithms[{i}]")

    def to_wire(self) -> dict[str, Any]:
        """The wire shape."""
        return {
            "v": self.v,
            "kind": self.kind,
            "verified_at": fields.render_instant(self.verified_at),
            "ledger": {
                "entries": self.ledger_entries,
                "head_seq": self.ledger_head_seq,
                "head_hash": self.ledger_head_hash,
            },
            "checkpoint": {"seq": self.checkpoint_seq, "estate_root": self.checkpoint_root},
            "key_id": self.key_id,
            "algorithms": list(self.algorithms),
        }

    @classmethod
    def from_wire(cls, value: object) -> Attestation:
        """Parse a received attestation."""
        doc = fields.require_mapping(value, "$")
        v = fields.require_major(doc)
        if fields.require(doc, "kind") != ATTESTATION_KIND:
            raise DocumentError("kind", f"expected {ATTESTATION_KIND!r}")
        ledger = fields.require_mapping(fields.require(doc, "ledger"), "ledger")
        checkpoint = fields.require_mapping(fields.require(doc, "checkpoint"), "checkpoint")
        algorithms = fields.require(doc, "algorithms")
        if not isinstance(algorithms, list):
            raise DocumentError("algorithms", "expected an array")
        return cls(
            v=v,
            verified_at=fields.timestamp(fields.require(doc, "verified_at"), "verified_at"),
            ledger_entries=fields.integer(
                fields.require(ledger, "entries"), "ledger.entries", minimum=1
            ),
            ledger_head_seq=fields.integer(fields.require(ledger, "head_seq"), "ledger.head_seq"),
            ledger_head_hash=parse_digest(
                fields.require(ledger, "head_hash"), field="ledger.head_hash"
            ),
            checkpoint_seq=fields.integer(fields.require(checkpoint, "seq"), "checkpoint.seq"),
            checkpoint_root=parse_digest(
                fields.require(checkpoint, "estate_root"), field="checkpoint.estate_root"
            ),
            key_id=fields.key_id(fields.require(doc, "key_id"), "key_id"),
            algorithms=tuple(algorithms),
        )
